# Appendix of Instacart Market Basket Analysis

After the competition, I wannted to try some ideas.

## How to run
* pendding

## Requirements

Python packages:
- numpy==1.12.1
- pandas==0.19.2
- scipy==0.19.0
- tqdm==4.11.2
- xgboost==0.6
