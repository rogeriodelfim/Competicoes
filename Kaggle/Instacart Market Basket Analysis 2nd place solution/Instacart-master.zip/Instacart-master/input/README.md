You need to put below files in this directory
- aisles.csv
- departments.csv
- order_products__prior.csv.gz
- order_products__train.csv.gz
- orders.csv.gz
- products.csv
- sample_submission.csv